% Set Data to robot arms
set(Robot_arm_1,'xdata',[Joint_1(1) Robot.X1],'ydata',[Joint_1(2) Robot.Y1])
set(Robot_arm_2,'xdata',[Robot.X1 Robot.X2],'ydata',[Robot.Y1 Robot.Y2])
