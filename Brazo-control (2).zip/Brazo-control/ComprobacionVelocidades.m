clc;
clear;

escala = 1.33;
A=15*escala/(2*(2.54));
rotacion = 50;
velocidad = 7;%cm/s
paso=0.06;
tau_m1=0.04806;
tau_m2=0.018436;
K_m1=7.22757;
K_m2=158.34479;
%theta=0:paso:2*pi;
syms t;

h=26;%25.945 cm
d=32;%31.604 cm
L1=30;%cm
L2=24;%cm
omega=velocidad/(A*2.54);%rad/s
theta=omega*t;
r=A*(2+0.54*cos(4*theta+rotacion));

tiempo_lim=2*pi/omega;
taux=0:0.1:tiempo_lim;


Beta=atan((h+sin(theta)*r)/(d+cos(theta)*r));
L3=sqrt((h+r*sin(theta))^2+(d+r*cos(theta))^2);
Alfa=acos((L1^2+L3^2-L2^2)/(2*L1*L3));
Delta=acos((L1^2+L2^2-L3^2)/(2*L1*L2));
Theta1=Beta+Alfa;
Theta1_aux=double(subs(Theta1,t,taux));
Theta2=pi+Delta;
Theta2_aux=subs(Theta2,t,taux);
Xmat=L1*cos(Theta1)+L2*cos(Theta1+Theta2);
Ymat=L1*sin(Theta1)+L2*sin(Theta1+Theta2);
dXmat=diff(Xmat);
dYmat=diff(Ymat);
vel=sqrt((dXmat*omega)^2+(dYmat*omega)^2);

figure(1)
fplot(Xmat,Ymat);
xlim([0 45]);
ylim([0 45]);
grid on
title('Trebol Escala 1.33');
xlabel('distancia x(cm)');
ylabel('distancia y(cm)');

figure(2)
Theta1d=rad2deg(Theta1);
fplot(t,Theta1d,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
ylim([0 95]);
grid on
title('\theta_1');
xlabel('tiempo(s)');
ylabel('Angulo(°)');
figure(3);
Theta2d=rad2deg(Theta2);
fplot(t,Theta2d,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
%ylim([0 95]);
grid on
title('\theta_2');
xlabel('tiempo(s)');
ylabel('Angulo(°)');

dtheta1_dtheta=diff(Theta1);
dtheta2_dtheta=diff(Theta2);

dtheta1_dt=dtheta1_dtheta.*omega;
dtheta2_dt=dtheta2_dtheta.*omega;
ddtheta1_dt=diff(dtheta1_dt);
ddtheta2_dt=diff(dtheta2_dt);

figure(4);
dTheta1d=rad2deg(dtheta1_dt);
fplot(t,dTheta1d,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
grid on
tit='$\dot{\theta_1}$';
title(tit,'interpreter','latex');
xlabel('tiempo(s)');
ylabel('Angulo(°)');

figure(5);
dTheta2d=rad2deg(dtheta2_dt);
fplot(t,dTheta2d,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
%ylim([0 95]);
grid on
tit='$\dot{\theta_2}$';
title(tit,'interpreter','latex');
xlabel('tiempo(s)');
ylabel('Angulo(°)');

figure(6);
ddTheta1d=rad2deg(ddtheta1_dt);
fplot(t,ddTheta1d,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
grid on
tit='$\ddot{\theta_1}$';
title(tit,'interpreter','latex');
xlabel('tiempo(s)');
ylabel('Angulo(°)');

figure(7);
ddTheta2d=rad2deg(ddtheta2_dt);
fplot(t,ddTheta2d,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
grid on
tit='$\ddot{\theta_2}$';
title(tit,'interpreter','latex');
xlabel('tiempo(s)');
ylabel('Angulo(°)');
%% configurar brazo
tau_m1=0.04806;
% 0.04806;
tau_m2=0.018436;
K_m1=4.415468062;
%4.415468062
%7.22757
K_m2=11.14583642;
%11.14583642
%158.34479
% Crear un objeto de comunicación serie
arduino = serial('COM3', 'BaudRate', 2000000);  % Reemplaza 'COM3' con el puerto USB de tu Arduino
% Abrir la comunicación serie
fopen(arduino);

Esquematico_robot;
% Run Simulation
SimOut = sim('Simu_controladores.slx'); %Run Simulink 
% Simulation Loop
% t_1=SimOut.theta_1.signals.values;
% t_2=SimOut.theta_2.signals.values;
% X=30.*cosd(t_1)+24.*cosd(t_1+t_2);
% Y=30.*sind(t_1)+24.*sind(t_1+t_2);
t_1_desired=SimOut.theta_1_int.signals.values;
t_2_desired=SimOut.theta_2_int.signals.values;
X1=30.*cosd(t_1_desired)+24.*cosd(t_1_desired+t_2_desired);
Y1=30.*sind(t_1_desired)+24.*sind(t_1_desired+t_2_desired);
%plot(X,Y,'r');
% plot(X1,Y1,'b');
%plot(SimOut.X2_out.signals.values,SimOut.Y2_out.signals.values,'r.');
 for S = 1 : 1 : size(SimOut.X1_out.signals.values)  
    Robot.X1 = SimOut.X1_out.signals.values(S);
    Robot.Y1 = SimOut.Y1_out.signals.values(S);
    Robot.X2 = SimOut.X2_out.signals.values(S);
    Robot.Y2 = SimOut.Y2_out.signals.values(S);

    Graficar_movimiento;  
    
    plot(Robot.X2,Robot.Y2,'r.');
    plot(X1,Y1,'--b')
    % Enviar datos al Arduino
    trama = [num2str(SimOut.theta_1_int.signals.values(S)) ',' num2str(SimOut.theta_2_int.signals.values(S)) ];  % Puedes cambiar este valor según lo que desees enviar
    fprintf(arduino, '%s\n', trama,'sync');
    pause(0.5)   
 end
 % Cerrar la comunicación serie
fclose(arduino);

% Limpieza
delete(arduino);
clear arduino;

%% torque
Iz_2=1.90567*10^-4;
Iz_1=8.32063*10^-4;
m_1=0.225;
m_2=0.028;
lc_1=28.2634/100;
lc_2=18.5429/100;
l_1=L1/100;
l_2=L2/100;
theta_2=Theta2;
theta_1=Theta1;
c_1=cos(theta_1);
c_2=cos(theta_2);
s_1=sin(theta_1);
s_2=sin(theta_2);
s_12=sin(theta_1+theta_2);
c_12=cos(theta_1+theta_2);
g=9.81;
dd_theta_1=ddtheta1_dt;
d_theta_1=dtheta1_dt;
dd_theta_2=ddtheta2_dt;
d_theta_2=dtheta2_dt;

%Para el T1
A=m_1*(lc_1^2)+Iz_1+m_2*l_1^2+m_2*(lc_2)^2+Iz_2+2*m_2*l_1*lc_2*c_2;
B=m_2*(lc_2^2)+Iz_2+m_2*l_1*lc_2*c_2;
D=-1*2*m_2*l_1*lc_2*s_2;
E=-1*s_2*m_2*l_1*lc_2;
U_1=g*((m_1*lc_1+m_2*l_1)*c_1+m_2*lc_2*c_12);
T1=A*dd_theta_1+B*dd_theta_2+D*d_theta_1*d_theta_2+E*(d_theta_2)^2+U_1;

%Para el T2
F= (m_2*(lc_2)^2+m_2*l_1*lc_2*c_2+Iz_2);
H= m_2*(lc_2)^2+Iz_2;
N= -1*m_2*l_1*lc_2*s_2;
O= m_2*l_1*lc_2*s_2;
P= m_2*l_1*lc_2*s_2;
U_2=g*m_2*lc_2*c_12;

T2=F*dd_theta_1+H*dd_theta_2+N*d_theta_1*d_theta_2+O*(d_theta_1)^2+P*d_theta_1*d_theta_2+U_2;
Torque1_aux=subs(T1,t,taux);
Torque2_aux=subs(T2,t,taux);
T_pico1=double(max(Torque1_aux));
T_rms1=double(rms(Torque1_aux));
T_rms2=double(rms(Torque2_aux));
T_pico2=double(max(Torque2_aux));

figure(9);
fplot(t,T1,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
%ylim([0 95]);
grid on
[tp s]=title('\tau_1',sprintf('T_{rms}=%.4f & T_{pico}=%.4f ',T_rms1,T_pico1));%.5f ;
xlabel('tiempo(s)');
ylabel('Torque(N-m)');

figure(10);
fplot(t,T2,[0 tiempo_lim]);
xlim([0 tiempo_lim]);
%ylim([0 95]);
grid on
[tp s]=title('\tau_2',sprintf('T_{rms}=%.4f & T_{pico}=%.4f ',T_rms2,T_pico2));%.5f ;
xlabel('tiempo(s)');
ylabel('Torque(N-m)');




% figure(5)
% fplot(t,T1,[0 7])
% figure(6)
% fplot(t,T2,[0 7])



